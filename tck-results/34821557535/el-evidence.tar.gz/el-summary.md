# Jakarta Expression Language TCK Evidence

- Commit: f2851dfa31629d0b3dfef8b5d950722a1e69d25b
- Project version: 1.1.0-SNAPSHOT
- Expression Language API baseline: 6.0.1
- TCK bundle: jakarta-expression-language-tck-6.0.1 (6.0 branch)
- Workflow: https://github.com/micronaut-projects/micronaut-jakarta-el/actions/runs/34821557535
- Sanitized JUnit XML: junit-xml/
- Tests: 360
- Failures: 0
- Errors: 0
- Skipped: 0

The signature test of the TCK is excluded: it verifies the signatures of the jakarta.el API jar, which
this repository consumes unchanged rather than implements.
