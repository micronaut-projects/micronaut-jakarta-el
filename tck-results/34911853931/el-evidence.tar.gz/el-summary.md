# Jakarta Expression Language TCK Evidence

- Commit: 7bcd4382fe3c11c098e94800975c074100c83b7c
- Project version: 1.1.1-SNAPSHOT
- Expression Language API baseline: 6.0.1
- TCK bundle: jakarta-expression-language-tck-6.0.1 (6.0 branch)
- Workflow: https://github.com/micronaut-projects/micronaut-jakarta-el/actions/runs/34911853931
- Sanitized JUnit XML: junit-xml/
- Tests: 360
- Failures: 0
- Errors: 0
- Skipped: 0

The signature test of the TCK is excluded: it verifies the signatures of the jakarta.el API jar, which
this repository consumes unchanged rather than implements.
